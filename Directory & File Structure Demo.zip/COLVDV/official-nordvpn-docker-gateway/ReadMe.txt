https://github.com/colvdv/official-nordvpn-docker-gateway/
Directory & File Structure Demo

Inside of this folder there are two folders:
	- The home folder is meant to symbolize your home folder (~/).
	- The mnt folder is meant to symbolize your mnt folder located in root.

Take a look at the GitHub guide and browse through the folder structure to get an idea of how everything is laid out. I've only added this for additional clarity in case anyone is confused as to how my structure is set up from the guide alone.
